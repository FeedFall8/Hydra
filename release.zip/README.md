# Hydra
a public MCBE anti cheat that is free, open source and public for all!
# Terms of usage
if you are using hydra, and/or its foundation code please follow the terms:

- you may NOT redistribute hydra as your own and monetize it
- you are strictly binded to the GNU liscence and therefore must comply and keep any redistributions free and secure
- we ask you credit us via ingame chat with hydra(this means dont cut out code that is for crediting!)
- we will punish you if you violate any of these terms
- again do not monetize hydra!!
©2020, FeedFall8, All Rights Reserved.